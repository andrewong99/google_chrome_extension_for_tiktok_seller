document.getElementById('autoCopy').addEventListener('click', async () => {
  try {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: () => {
        const regex = /\b\d{18}\b/g;
        const bodyText = document.body.textContent;
        const links = document.querySelectorAll('a');
        let numbers = bodyText.match(regex) || [];

        // Check inside <a> tags for 18-digit numbers
        links.forEach(link => {
          const linkText = link.textContent.match(regex);
          if (linkText) {
            numbers = numbers.concat(linkText);
          }
        });

        console.log(`Found ${numbers.length} 18-digit numbers:`, numbers);

        if (numbers.length > 0) {
          // Prepend a single apostrophe to each number
          const numbersText = numbers.map(num => '\'' + num).join('\n');

          const tempTextarea = document.createElement('textarea');
          tempTextarea.value = numbersText;
          document.body.appendChild(tempTextarea);

          tempTextarea.select();
          document.execCommand('copy');

          document.body.removeChild(tempTextarea);

          console.log('18-digit numbers copied to clipboard:', numbersText);
          alert('18-digit numbers copied to clipboard!');
        } else {
          console.log('No 18-digit numbers found on the page.');
          alert('No 18-digit numbers found on the page.');
        }
      }
    });

    window.close();
  } catch (error) {
    console.error('Failed to copy 18-digit numbers:', error);
    alert('Failed to copy 18-digit numbers. Please check the console for more details.');
  }
});
