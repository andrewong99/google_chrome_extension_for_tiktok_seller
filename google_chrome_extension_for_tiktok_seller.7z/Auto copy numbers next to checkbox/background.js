chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: copyEighteenDigitNumbers
    });
  } catch (error) {
    console.error('Failed to copy 18-digit numbers:', error);
  }
});

function copyEighteenDigitNumbers() {
  const regex = /\b\d{18}\b/g;
  const bodyText = document.body.textContent;  // Extract all text content
  const links = document.querySelectorAll('a');  // Extract text from all links
  let numbers = bodyText.match(regex) || [];

  // Check inside <a> tags for 18-digit numbers
  links.forEach(link => {
    const linkText = link.textContent.match(regex);
    if (linkText) {
      numbers = numbers.concat(linkText);
    }
  });

  console.log(`Found ${numbers.length} 18-digit numbers:`, numbers);

  if (numbers.length > 0) {
    const numbersText = numbers.join('\n');

    // Focus the document before copying
    window.focus();

    navigator.clipboard.writeText(numbersText).then(() => {
      console.log('18-digit numbers copied to clipboard:', numbersText);
    }).catch(err => {
      console.error('Failed to copy 18-digit numbers:', err);
      alert('Failed to copy 18-digit numbers. Please check the console for more details.');
    });
  } else {
    console.log('No 18-digit numbers found on the page.');
    alert('No 18-digit numbers found on the page.');
  }
}
