document.getElementById('autoClick').addEventListener('click', async () => {
  try {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: clickLinksNextToCheckbox
    });
  } catch (error) {
    console.error('Failed to click links next to checkbox:', error);
  }
});

function clickLinksNextToCheckbox() {
  const checkboxes = document.querySelectorAll('input[type="checkbox"]');
  checkboxes.forEach(checkbox => {
    let parent = checkbox.parentElement;
    let link = null;

    // Traverse up the DOM tree to find the nearest link element
    while (parent) {
      link = parent.querySelector('a');
      if (link) {
        link.click();
        break;
      }
      parent = parent.parentElement;
    }

    // If no link is found in the parent hierarchy, check the next sibling
    if (!link) {
      let sibling = checkbox.nextElementSibling;
      while (sibling) {
        if (sibling.tagName === 'A') {
          sibling.click();
          break;
        }
        sibling = sibling.nextElementSibling;
      }
    }
  });
}
